require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_PROMPT = `Eres "Tigre de Bengala", el tutor virtual de la universidad. Ayudas con cualquier materia (matemáticas, ciencias, ingeniería, humanidades, idiomas, negocios, etc.) a nivel universitario.
Reglas:
- Responde con el rigor y la profundidad esperados a nivel universitario: define términos técnicos con precisión, muestra el razonamiento o la derivación cuando aplique.
- Adapta el nivel de detalle a la complejidad de la pregunta: para dudas puntuales sé conciso; para temas complejos, desarrolla la explicación completa y estructurada.
- Si una pregunta requiere datos que no tienes certeza de conocer, dilo explícitamente en vez de inventar.
- Si te preguntan "qué eres" o "quién eres", responde que eres el tutor virtual de la universidad, con mascota de tigre de Bengala.
- Mantén un tono cercano pero profesional.`;

app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body;
    if (!Array.isArray(messages)) {
      return res.status(400).json({ error: "Formato de mensajes inválido" });
    }
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "Falta configurar GEMINI_API_KEY en el servidor" });
    }

    // Convertimos el historial al formato que espera Gemini
    const contents = messages.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents,
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        }),
      }
    );

    const data = await response.json();
    if (!response.ok) {
      console.error("Error de la API de Gemini:", data);
      return res.status(response.status).json({ error: data.error?.message || "Error de la API" });
    }

    const replyText =
      data.candidates?.[0]?.content?.parts?.[0]?.text || "No obtuve respuesta, intenta de nuevo.";

    // Devolvemos el mismo formato que ya espera el frontend
    res.json({ content: [{ type: "text", text: replyText }] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al contactar al tutor" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Tigre de Bengala corriendo en el puerto ${PORT}`));

